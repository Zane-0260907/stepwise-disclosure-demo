import {nativeTau} from './native-tau-v10.mjs';
import {createHash} from 'node:crypto';
import {boundViews,BOUND_VIEW_INSTRUCTION} from './bound-views-v10.mjs';
const sha=s=>createHash('sha256').update(s).digest('hex');
export const NATIVE_SYSTEM='You are a customer service agent. Follow the supplied domain policy. On a turn, either call exactly one tool OR send a message to the user. Obtain the explicit confirmations required by policy before state-changing actions. Never fabricate records or ignore a failed tool result.';
export async function runNativeTask(item,connection,{userGuidelines,recordCall=()=>{},onEvent=()=>{},maxAgentCalls=40,maxUserCalls=20,viewMode='full'}={}){
 const bridge=nativeTau();const views=boundViews({mode:viewMode});const record={caseId:item.id,domain:item.domain,method:'native-'+viewMode,status:'running',startedAt:new Date().toISOString(),calls:[],actions:[],conversation:[],protocolViolations:[]};
 async function model(role,messages,tools){
  const body=JSON.stringify({model:'deepseek-flash',temperature:0,messages,max_tokens:role==='agent'?1700:700,...(tools?{tools,parallel_tool_calls:false}: {})});
  const started=performance.now();await recordCall({phase:'before',role,body});
  const response=await fetch(connection.url,{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+connection.token},body,signal:AbortSignal.timeout(95000)});
  const responseBody=await response.text();let data;try{data=JSON.parse(responseBody);}catch{data={};}
  const c={index:record.calls.length,role,requestBody:body,requestSha256:sha(body),responseBody,responseSha256:sha(responseBody),status:response.status,usage:data.usage||null,elapsedMs:performance.now()-started};
  record.calls.push(c);await recordCall({phase:'after',role,call:c});onEvent({type:'model.returned',role,index:c.index});
  if(!response.ok)throw Error('MODEL_HTTP_'+response.status);
  if(!data.choices?.[0]?.message)throw Error('EMPTY_MODEL_MESSAGE');
  return data.choices[0].message;
 }
 try{
  const info=await bridge.call({command:'init',domain:item.domain});record.initialDbHash=info.dbHash;
  const agent=[{role:'system',content:NATIVE_SYSTEM+'\n\n'+info.policy+(viewMode==='full'?'':'\n\n'+BOUND_VIEW_INSTRUCTION)}];
  const user=[{role:'system',content:userGuidelines+'\n\n<scenario>\n'+JSON.stringify(item.userScenario)+'\n</scenario>'},{role:'user',content:'Please begin the customer service conversation.'}];
  let agentCalls=0,userCalls=0,needUser=true;
  while(agentCalls<maxAgentCalls&&userCalls<maxUserCalls){
   if(needUser){
    const reply=await model('user-simulator',user);userCalls++;const content=reply.content||'';
    user.push({role:'assistant',content});record.conversation.push({role:'user',content});
    if(/###(?:STOP|TRANSFER|OUT-OF-SCOPE)###/.test(content)){record.status='completed';record.stopReason=content;break;}
    agent.push({role:'user',content});needUser=false;
   }
   const message=await model('agent',agent,info.tools);agentCalls++;
   if(message.tool_calls?.length){
    if(message.tool_calls.length!==1)record.protocolViolations.push({callIndex:record.calls.length-1,type:'multiple-tools',count:message.tool_calls.length});
    if(message.content?.trim())record.protocolViolations.push({callIndex:record.calls.length-1,type:'text-with-tools'});
    agent.push({role:'assistant',content:message.content??null,tool_calls:message.tool_calls});
    // The upstream text orchestrator executes every tool call in order. Policy
    // violations remain visible and are not counted as policy-compliant success.
    for(const tool of message.tool_calls){
    let args;try{args=JSON.parse(tool.function.arguments);}catch{throw Error('INVALID_TOOL_JSON');}
    const started=performance.now();let result,boundArgs=args;
    try{
     if(viewMode!=='full'){
      const snapshot=await bridge.call({command:'snapshot'});boundArgs=views.bind(tool.function.name,args,snapshot.db);
     }
     result=await bridge.call({command:'call',name:tool.function.name,arguments:boundArgs});
    }
    catch(error){result={result:{error:error.message},errorType:'AdapterValidationError'};}
    const observation=views.project(result.result,{sourceRoot:views.sourceRoot(tool.function.name,boundArgs,result.result,item.domain)});
    const action={callIndex:record.calls.length-1,toolCallId:tool.id,name:tool.function.name,arguments:boundArgs,plannerArguments:args,observation,...result,elapsedMs:performance.now()-started};
    record.actions.push(action);onEvent({type:'tool.returned',name:action.name,error:action.errorType});
    agent.push({role:'tool',tool_call_id:tool.id,content:JSON.stringify(observation)});
    if(tool.function.name==='transfer_to_human_agents'){record.status='completed';record.stopReason='transfer_to_human_agents';break;}
    }
    if(record.status==='completed')break;
   }else{
    const content=message.content||'';agent.push({role:'assistant',content});record.conversation.push({role:'assistant',content});user.push({role:'user',content});needUser=true;
   }
  }
  if(record.status==='running'){record.status='failed';record.error='INTERACTION_LIMIT';}
 }catch(error){record.status='failed';record.error=error.message;}
 finally{
  try{const final=await bridge.call({command:'snapshot'});record.finalDbHash=final.dbHash;}catch{}
  await bridge.close();
 }
 record.viewEvents=views.events;record.finishedAt=new Date().toISOString();record.metrics={agentCalls:record.calls.filter(c=>c.role==='agent').length,userSimulatorCalls:record.calls.filter(c=>c.role==='user-simulator').length,totalTokens:record.calls.reduce((s,c)=>s+(c.usage?.total_tokens||0),0),nativeToolCalls:record.actions.length,stateChangingCalls:record.actions.filter(a=>a.mutatesState&&!a.errorType).length,toolErrors:record.actions.filter(a=>a.errorType).length};
 return record;
}
