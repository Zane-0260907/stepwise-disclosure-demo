import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {resolve} from 'node:path';
export function nativeTau({python=process.env.TAU_PYTHON||resolve('data/research/v10-python',process.platform==='win32'?'Scripts/python.exe':'bin/python')}={}){
 const processHandle=spawn(python,['scripts/native_tau_bridge.py'],{stdio:['pipe','pipe','pipe'],windowsHide:true});
 const pending=[];let stderr='';
 processHandle.stderr.on('data',x=>{stderr=(stderr+x.toString()).slice(-4000);});
 const lines=createInterface({input:processHandle.stdout});
 lines.on('line',line=>{const p=pending.shift();if(!p)return;try{const data=JSON.parse(line);data.ok?p.resolve(data.result):p.reject(Error(data.error));}catch(e){p.reject(e);}});
 const fail=error=>{while(pending.length)pending.shift().reject(error);};
 processHandle.on('error',fail);processHandle.on('exit',code=>{if(pending.length)fail(Error('NATIVE_EXIT '+code+' '+stderr));});
 return {call:message=>new Promise((resolve,reject)=>{pending.push({resolve,reject});processHandle.stdin.write(JSON.stringify(message)+'\n');}),
  close:()=>{processHandle.stdin.end();return new Promise(resolve=>processHandle.once('exit',resolve));}};
}
